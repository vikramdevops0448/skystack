
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SkyStack Solutions</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { font-family: Arial, sans-serif; padding-top: 60px; }
    header { background: #007BFF; color: white; padding: 20px 0; text-align: center; }
    nav a { color: white; margin: 0 15px; text-decoration: none; }
    nav a:hover { text-decoration: underline; }
    footer { background: #f8f9fa; text-align: center; padding: 15px; margin-top: 40px; }
  </style>
</head>
<body>
  <header>
    <h2>SkyStack Solutions</h2>
    <nav>
      <a href="index.php">Home</a> |
      <a href="about.php">About</a> |
      <a href="courses.php">Courses</a> |
      <a href="projects.php">Projects</a> |
      <a href="placement.php">Placement</a> |
      <a href="services.php">Services</a> |
      <a href="contact.php">Contact</a>
    </nav>
  </header>
  <main class="container">
