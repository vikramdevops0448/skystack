<?php include 'includes/header.php'; ?>
<section class="text-center py-5" style="background: linear-gradient(120deg, #e0f7fa, #ffffff);">
  <div class="container">
    <h1 class="display-5 fw-bold">DevOps with AWS Cloud & SRE Batch</h1>
    <h2 class="text-danger fw-bold mb-4">Starting from 25th July 2025</h2>
    <p class="lead mb-4">Register now and reserve your spot. Get trained with real-time projects from Day 1!</p>
    <div class="d-grid gap-2 d-sm-flex justify-content-sm-center">
      <a href="courses.php" class="btn btn-primary btn-lg px-4 gap-3">Get Syllabus</a>
      <a href="contact.php" class="btn btn-outline-secondary btn-lg px-4">Join Free Webinar</a>
    </div>
    <img src="assets/trainer_photo.jpg" alt="Trainer Photo" class="img-fluid rounded-circle mb-4" style="max-width: 200px;">
<div class="row mt-5">
      <div class="col-md-6 offset-md-3">
        <div class="d-flex justify-content-around align-items-center flex-wrap">
          <img src="https://img.icons8.com/color/48/000000/amazon-web-services.png" alt="AWS"/>
          <img src="https://img.icons8.com/color/48/000000/docker.png" alt="Docker"/>
          <img src="https://img.icons8.com/color/48/000000/kubernetes.png" alt="Kubernetes"/>
          <img src="https://img.icons8.com/color/48/000000/linux.png" alt="Linux"/>
          <img src="https://img.icons8.com/color/48/000000/jenkins.png" alt="Jenkins"/>
          <img src="https://img.icons8.com/color/48/000000/terraform.png" alt="Terraform"/>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="text-center py-4">
  <div class="container">
    <h4>What You’ll Get</h4>
    <ul class="list-unstyled">
      <li>✔ Interview Preparation from Day 1</li>
      <li>✔ Real-Time Projects for Every Module</li>
      <li>✔ Daily Standup Calls & Guidance</li>
    </ul>
  </div>
</section>
<?php include 'includes/footer.php'; ?>