<?php include 'includes/header.php'; ?>
<h1>Contact Us</h1>
<form method="POST" action="sendmail.php">
    <label>Name:</label><input type="text" name="name"><br>
    <label>Email:</label><input type="email" name="email"><br>
    <label>Message:</label><textarea name="message"></textarea><br>
    <input type="submit" value="Send">
</form>
<?php include 'includes/footer.php'; ?>