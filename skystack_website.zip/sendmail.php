<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $to = "youremail@example.com"; // change to your receiving email
    $subject = "Contact from SkyStack Website";
    $body = "Name: ".$_POST['name']."\nEmail: ".$_POST['email']."\nMessage: ".$_POST['message'];
    $headers = "From: ".$_POST['email'];
    if(mail($to, $subject, $body, $headers)){
        echo "Email sent successfully!";
    } else {
        echo "Email sending failed.";
    }
}
?>